import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-VQU75VYZ.js";
import "./chunk-4JHUYXLP.js";
import "./chunk-S5H4AKYS.js";
import "./chunk-UC72YTJX.js";
import "./chunk-QSOY3OHJ.js";
import "./chunk-NBDUMOBL.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
